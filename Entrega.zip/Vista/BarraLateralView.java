package Vista;

import java.awt.*;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSplitPane;

import Modelo.Animal;

public class BarraLateralView extends JPanel{
    private int WIDTH=300;
    public BarraLateralView(){
        setPreferredSize(new Dimension(WIDTH,800));
        crearSelecciones(null);
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d= (Graphics2D)g;
        crearFondo(g2d);
    }
    public void crearFondo(Graphics2D g){
        g.setColor(new Color(220,230,228));
        g.fillRect(0,0,getWidth(),getHeight());
    }
    public void crearSelecciones(Animal[] misAnimales){
        JSplitPane Division=new JSplitPane(	JSplitPane.HORIZONTAL_SPLIT); 
            Division.setPreferredSize(new Dimension(WIDTH, 30));
        JButton Boton=new JButton("Leon");
            Boton.setPreferredSize(new Dimension((WIDTH/3),20));
            Boton.setBackground(new Color(220,230,228));
        JLabel Especie= new JLabel("Carnivoro");
            Especie.setPreferredSize(new Dimension((WIDTH/3)*2,20));
            Especie.setBackground(new Color(220,230,228));
        Division.add(Boton);
        Division.add(new JLabel("Carnivoro"));
        

        add(Division);
    }
}
